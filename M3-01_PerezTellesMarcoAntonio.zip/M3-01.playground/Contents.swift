

func main(){

    var opc : Int = 0
    var num1: Float = 0
    var num2: Float = 0

     repeat {

        print("Ingrese la opción:")
        print("1. Sumar")
        print("2. Restar")
        print("3. Multiplicar")
        print("4. Dividir")
        
        if let input = readLine(), let inputAsInt = Int(input) {
            opc = inputAsInt

            switch opc {
            case 1:
                print("Ingrese el primer número:")
                if let input = readLine(), let inputAsFloat = Float(input) {
                    num1 = inputAsFloat
                }
                print("Ingrese el segundo número:")
                if let input = readLine(), let inputAsFloat = Float(input) {
                    num2 = inputAsFloat
                }
                sumar(num1: num1, num2: num2)

            case 2:
                print("Ingrese el primer número:")
                if let input = readLine(), let inputAsFloat = Float(input) {
                    num1 = inputAsFloat
                }
                print("Ingrese el segundo número:")
                if let input = readLine(), let inputAsFloat = Float(input) {
                    num2 = inputAsFloat
                }
                restar(num1: num1, num2: num2)

            case 3:
                print("Ingrese el primer número:")
                if let input = readLine(), let inputAsFloat = Float(input) {
                    num1 = inputAsFloat
                }
                print("Ingrese el segundo número:")
                if let input = readLine(), let inputAsFloat = Float(input) {
                    num2 = inputAsFloat
                }
                multiplicar(num1: num1, num2: num2)

            case 4:
                print("Ingrese el primer número:")
                if let input = readLine(), let inputAsFloat = Float(input) {
                    num1 = inputAsFloat
                }
                print("Ingrese el segundo número:")
                if let input = readLine(), let inputAsFloat = Float(input) {
                    num2 = inputAsFloat
                }
                dividir(num1: num1, num2: num2)

            default:
                print("Adiós")
            }


        } else {
            print("Opción no válida")
        }

    } while opc != 0
}


func sumar(num1: Float, num2: Float){

    print("\(num1) + \(num2) = \(num1 + num2)")

}

func restar(num1: Float, num2: Float){

     print("\(num1) - \(num2) = \(num1 - num2)")

}

func multiplicar(num1: Float, num2: Float){

     print("\(num1) * \(num2) = \(num1 * num2)")

}

func dividir(num1: Float, num2: Float){

    if(num2 == 0){
        print("Nan")
    }

     print("\(num1) / \(num2) = \(num1 / num2)")
}

main()
