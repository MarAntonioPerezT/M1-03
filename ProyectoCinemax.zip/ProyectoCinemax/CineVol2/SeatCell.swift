//
//  SeatCell.swift
//  Cinevol2
//
//  Created by Facultad Contaduría y Administración on 23/05/23.
//

import UIKit

class SeatCell: UICollectionViewCell {
    
    @IBOutlet var imgSeat: UIImageView!
    
    func setUp(with seat: Seat)
    {
        if seat.status == .empty
        {
            
            imgSeat.image = UIImage(systemName: "chair.lounge")
            imgSeat.tintColor = UIColor.lightGray
            
        } else {
            
            if seat.status == .ocuppied {
                
                imgSeat.image = UIImage(systemName: "person")
                
            } else {
                
                if seat.status == .reserved
                {
                    imgSeat.image = UIImage(systemName: "chair.lounge.fill")
                    imgSeat.tintColor = UIColor.blue
                    

                }
            }
        }
    }
}
