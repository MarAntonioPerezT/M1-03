//
//  ViewController.swift
//  Cinevol2
//
//  Created by Facultad de Contaduría y Administración on 09/05/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet var collectionViewB: UICollectionView!
    
    var selectedCollection: UICollectionView!
    var selectedIndexPath: IndexPath?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionViewB.dataSource = self
        collectionViewB.delegate = self
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let vc = segue.destination as? DetalleVC {
            if selectedCollection == self.collectionViewB {
                if let indexPath = selectedIndexPath {
                    let movie = movies[indexPath.row]
                    vc.movie = movie
                }
            } else if selectedCollection == self.collectionView {
                if let indexPath = selectedIndexPath {
                    let movie = popularMovies[indexPath.row]
                    vc.movie = movie
                }
            }
        }
    }
}

extension ViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, UICollectionViewDelegate {
        
        func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            if collectionView == self.collectionView{
                return popularMovies.count
            }
            return movies.count
            
        }
        
        func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
            if collectionView == self.collectionView {
                let cellA = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieCollectionViewCell", for: indexPath) as! MovieCollectionViewCell
                cellA.setup(with: popularMovies[indexPath.row])
                cellA.movieImageView.layer.cornerRadius = 20.0
                return cellA
            } else {
                let cellB = collectionView.dequeueReusableCell(withReuseIdentifier: "MovieCollectionViewCell", for: indexPath) as! MovieCollectionViewCell
                cellB.setupB(with: movies[indexPath.row])
                return cellB
            }
            
        }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == self.collectionView {
            return CGSize(width:361,height: 190)
        } else {
            return CGSize(width: 170, height: 200)
        }
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedCollection = collectionView
        selectedIndexPath = indexPath
        performSegue(withIdentifier: "VCMainVCDetllas", sender: nil)
    }
}



