//
//  Movie.swift
//  Cinevol2
//
//  Created by Facultad de Contaduría y Administración on 09/05/23.
//

import Foundation
import UIKit

struct Movie {
    let id: Int
    let images: [UIImage]
    let title: String
    let description: String
    let classification: String
}

let movies: [Movie] = [
    
    Movie(id:1, images: [UIImage(named: "mario")!, UIImage(named: "mario2")!], title: "Mario Bros", description: "Description", classification: "A"),
    Movie(id:2, images: [UIImage(named: "moon")!, UIImage(named: "moon2")!], title: "Moon Light", description: "Description", classification: "B-15"),
    Movie(id:3, images: [UIImage(named: "buzzL")!, UIImage(named: "buzz")!], title: "Buuz Lightyear", description: "Description", classification: "Clasificación de Transformers"),
    Movie(id:4, images: [UIImage(named: "quan")!, UIImage(named: "quan2")!], title: "Quantumania", description: "Descripción de Miles", classification: "Clasificación de Miles"),
    Movie(id:5, images: [UIImage(named: "bpL")!, UIImage(named: "bp")!], title: "Black Phone", description: "Descripción de La La Land", classification: "Clasificación de La La Land"),
    Movie(id:6, images: [UIImage(named: "db")!, UIImage(named: "db2")!], title: "Dragon Ball Super", description: "Descripción de Guardianes de la Galaxia", classification: "Clasificación de Guardianes de la Galaxia"),
    Movie(id:7, images: [UIImage(named: "ana")!, UIImage(named: "ana2")!], title: "Anabelle", description: "Descripción de Harry Potter y la Piedra Filosofal", classification: "B"),
    Movie(id:8, images: [UIImage(named: "yn2")!, UIImage(named: "yn")!], title: "Your Name", description: "Descripción de Titanic", classification: "Clasificación de Titanic")
    
]

let popularMovies: [Movie] = [
    
    Movie(id:1, images: [UIImage(named: "mario")!, UIImage(named: "mario2")!], title: "Mario Bros", description: "Description", classification: "A"),
    Movie(id:2, images: [UIImage(named: "moon")!, UIImage(named: "moon2")!], title: "Moon Light", description: "Description", classification: "B-15"),
    Movie(id:3, images: [UIImage(named: "buzzL")!, UIImage(named: "buzz")!], title: "Buuz Lightyear", description: "Description", classification: "Clasificación de Transformers"),
    Movie(id:4, images: [UIImage(named: "quan")!, UIImage(named: "quan2")!], title: "Quantumania", description: "Descripción de Miles", classification: "Clasificación de Miles"),
    Movie(id:5, images: [UIImage(named: "bpL")!, UIImage(named: "bp")!], title: "Black Phone", description: "Descripción de La La Land", classification: "Clasificación de La La Land"),
    Movie(id:6, images: [UIImage(named: "db")!, UIImage(named: "db2")!], title: "Dragon Ball Super", description: "Descripción de Guardianes de la Galaxia", classification: "Clasificación de Guardianes de la Galaxia"),
    Movie(id:7, images: [UIImage(named: "ana")!, UIImage(named: "ana2")!], title: "Anabelle", description: "Descripción de Harry Potter y la Piedra Filosofal", classification: "B"),
    Movie(id:8, images: [UIImage(named: "yn2")!, UIImage(named: "yn")!], title: "Your Name", description: "Descripción de Titanic", classification: "Clasificación de Titanic")
]

//let movies: [Movie] = [
//    Movie(image: UIImage(named: //"avengers")!),
//Movie(image: UIImage(named: "bridesmaids")!),
//  Movie(image: UIImage(named: "guardians")!),
//  Movie(image: UIImage(named: //"harrypotter1")!),
//Movie(image: UIImage(named: "titanic")!),
//  Movie(image: UIImage(named: "zootopia")!)
//]
